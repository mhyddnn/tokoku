package com.example.tokoku;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listProduk;
    View dialogView;
    TextView tvNamaProduk, tvHargaProduk, tvJenisProduk, tvStokProduk, tvDeskProduk;
    LayoutInflater inflater;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));

        FloatingActionButton fab_addProduk = (FloatingActionButton) findViewById(R.id.fab_addProduk);
        fab_addProduk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, TambahActivity.class));
            }
        });

        dbHelper = new DBHelper(this);
        listProduk = findViewById(R.id.list_dataProduk);
        listProduk.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        SearchView searchView = (SearchView)menu.findItem(R.id.action_search).getActionView();
        SearchManager searchManager = (SearchManager)getSystemService(SEARCH_SERVICE);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setSubmitButtonEnabled(false);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchData(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                searchData(s);
                return false;
            }
        });

        return true;
    }

    private void searchData(String keyword) {
        Cursor cursor = dbHelper.searchDataProduk(keyword);
        CustomCursorAdapter customCursorAdapter = new CustomCursorAdapter(this, cursor, 1);
        listProduk.setAdapter(customCursorAdapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_about:
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
        }

        switch (item.getItemId()){
            case R.id.action_logout:
                onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    public void setListView() {
        Cursor cursor = dbHelper.getDataProduk();
        CustomCursorAdapter customCursorAdapter = new CustomCursorAdapter(this, cursor, 1);
        listProduk.setAdapter(customCursorAdapter);
    }

    public void onItemClick(AdapterView<?> parent, View view, int i, long x) {
        TextView getId = (TextView) view.findViewById(R.id.idListProduk);
        final long id = Long.parseLong(getId.getText().toString());
        final Cursor cursor = dbHelper.getDataProdukById(id);
        cursor.moveToFirst();

        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Pilihan");

        String[] options = {"Lihat Produk", "Edit Produk", "Hapus Produk"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                switch (which) {
                    case 0:
                        final AlertDialog.Builder viewData = new AlertDialog.Builder(MainActivity.this);
                        inflater = getLayoutInflater();
                        dialogView = inflater.inflate(R.layout.detail, null);
                        viewData.setView(dialogView);
                        viewData.setTitle("Detail produk");

                        tvNamaProduk = dialogView.findViewById(R.id.tv_nama);
                        tvHargaProduk = dialogView.findViewById(R.id.tv_harga);
                        tvJenisProduk = dialogView.findViewById(R.id.tv_jenis);
                        tvStokProduk = dialogView.findViewById(R.id.tv_stok);
                        tvDeskProduk = dialogView.findViewById(R.id.tv_desk);

                        tvNamaProduk.setText("  Nama produk : " + cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_namaProduk)));
                        tvHargaProduk.setText("  Harga produk : " + cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_hargaProduk)));
                        tvJenisProduk.setText("  Jenis produk : " + cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_jenisProduk)));
                        tvStokProduk.setText("  Stok produk : " + cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_stokProduk)));
                        tvDeskProduk.setText("  Deks produk : " + cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_deskProduk)));

                        viewData.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        viewData.show();
                }
                switch (which) {
                    case 1:
                        Intent iddata = new Intent(MainActivity.this, EditActivity.class);
                        iddata.putExtra(DBHelper.row_idProduk, id);
                        startActivity(iddata);
                }
                switch (which) {
                    case 2:
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
                        builder1.setMessage("Hapus produk ini?");
                        builder1.setCancelable(true);
                        builder1.setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dbHelper.deleteDataProduk(id);
                                Toast.makeText(MainActivity.this, "Produk Terhapus", Toast.LENGTH_SHORT).show();
                                setListView();
                            }
                        });
                        builder1.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alertDialog = builder1.create();
                        alertDialog.show();
                }
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    @Override
    protected void onResume() {
        super.onResume();
        setListView();
    }

    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Anda akan logout?");
        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.super.onBackPressed();
            }
        });
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}