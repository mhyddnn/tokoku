package com.example.tokoku;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.blogspot.atifsoftwares.circularimageview.CircularImageView;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

public class TambahActivity extends AppCompatActivity {

    DBHelper dbHelper;
    EditText txtNamaProduk, txtHargaProduk, txtStokProduk, txtDeskProduk;
    Spinner spJenisProduk;
    CircularImageView imageProduk;

    long id;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah);
        setSupportActionBar(findViewById(R.id.toolbar));

        dbHelper = new DBHelper(this);

        id = getIntent().getLongExtra(DBHelper.row_idProduk, 0);

        txtNamaProduk = findViewById(R.id.txtNamaProduk_Add);
        txtHargaProduk = findViewById(R.id.txtHargaProduk_Add);
        txtStokProduk = findViewById(R.id.txtStokProduk_Add);
        txtDeskProduk = findViewById(R.id.txtDeskProduk_Add);
        spJenisProduk = findViewById(R.id.spJenisProduk_Add);
        imageProduk = findViewById(R.id.image_produk);

        imageProduk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.startPickImageActivity(TambahActivity.this);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_produk:
                String nama = txtNamaProduk.getText().toString().trim();
                String harga = txtHargaProduk.getText().toString().trim();
                String jenis = spJenisProduk.getSelectedItem().toString().trim();
                String stok = txtStokProduk.getText().toString().trim();
                String desk = txtDeskProduk.getText().toString().trim();

                ContentValues values = new ContentValues();
                values.put(DBHelper.row_namaProduk, nama);
                values.put(DBHelper.row_hargaProduk, harga);
                values.put(DBHelper.row_jenisProduk, jenis);
                values.put(DBHelper.row_stokProduk, stok);
                values.put(DBHelper.row_deskProduk, desk);
                values.put(DBHelper. row_imageProduk, String.valueOf(uri));

                if (nama.equals("") || harga.equals("") || jenis.equals("") || stok.equals("") || desk.equals("")) {
                    Toast.makeText(TambahActivity.this, "Data tidak boleh kosong", Toast.LENGTH_SHORT).show();
                } else {
                    dbHelper.insertDataProduk(values);
                    Toast.makeText(TambahActivity.this, "Data berhasil tersimpan", Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
        return super.onOptionsItemSelected(item);
    }


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE
                && resultCode == Activity.RESULT_OK) {
            Uri imageuri = CropImage.getPickImageResultUri(this, data);
            if (CropImage.isReadExternalStoragePermissionsRequired(this, imageuri)) {
                uri = imageuri;
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}
                , 0);
            } else {
                startCrop(imageuri);
            }
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                imageProduk.setImageURI(result.getUri());
                uri = result.getUri();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void startCrop(Uri imageuri) {
        CropImage.activity(imageuri)
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(this);
        uri = imageuri;
    }
}