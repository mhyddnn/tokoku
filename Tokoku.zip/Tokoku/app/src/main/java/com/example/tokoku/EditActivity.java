package com.example.tokoku;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.blogspot.atifsoftwares.circularimageview.CircularImageView;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

public class EditActivity extends AppCompatActivity {

    DBHelper dbHelper;
    EditText txtNamaProduk, txtHargaProduk, txtStokProduk, txtDeskProduk;
    Spinner spJenisProduk;
    CircularImageView imageProduk;
//    Button btnProdukEdit;

    long id;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        setSupportActionBar(findViewById(R.id.toolbar));

        dbHelper = new DBHelper(this);

        id = getIntent().getLongExtra(DBHelper.row_idProduk, 0);

        txtNamaProduk = findViewById(R.id.txtNamaProduk_Edit);
        txtHargaProduk = findViewById(R.id.txtHargaProduk_Edit);
        spJenisProduk = findViewById(R.id.spJenisProduk_Edit);
        txtStokProduk = findViewById(R.id.txtStokProduk_Edit);
        txtDeskProduk = findViewById(R.id.txtDeskProduk_Edit);
        imageProduk = findViewById(R.id.image_produkEdit);

        imageProduk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.startPickImageActivity(EditActivity.this);
            }
        });

        getData();
    }

    private void getData() {
        Cursor cursor = dbHelper.getDataProdukById(id);
        if (cursor.moveToFirst()) {
            String nama = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_namaProduk));
            String harga = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_hargaProduk));
            String jenis = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_jenisProduk));
            String stok = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_stokProduk));
            String desk = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_deskProduk));
            String foto = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.row_imageProduk));

            txtNamaProduk.setText(nama);
            txtHargaProduk.setText(harga);

            if (jenis.equals("Pria")) {
                spJenisProduk.setSelection(0);
            } else if (jenis.equals("Perempuan")) {
                spJenisProduk.setSelection(1);
            } else if (jenis.equals("Unisex")) {
                spJenisProduk.setSelection(2);
            }

            txtStokProduk.setText(stok);
            txtDeskProduk.setText(desk);

            if (foto.equals("null")) {
                imageProduk.setImageResource(R.drawable.image);
            } else {
                imageProduk.setImageURI(Uri.parse(foto));
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit_produk:
                String nama = txtNamaProduk.getText().toString().trim();
                String harga = txtHargaProduk.getText().toString().trim();
                String jenis = spJenisProduk.getSelectedItem().toString().trim();
                String stok = txtStokProduk.getText().toString().trim();
                String desk = txtDeskProduk.getText().toString().trim();

                ContentValues values = new ContentValues();
                values.put(DBHelper.row_namaProduk, nama);
                values.put(DBHelper.row_hargaProduk, harga);
                values.put(DBHelper.row_jenisProduk, jenis);
                values.put(DBHelper.row_stokProduk, stok);
                values.put(DBHelper.row_deskProduk, desk);
                values.put(DBHelper.row_imageProduk, String.valueOf(uri));

                if (nama.equals("") || harga.equals("") || jenis.equals("") || stok.equals("") || desk.equals("")) {
                    Toast.makeText(EditActivity.this, "Data tidak boleh kosong", Toast.LENGTH_SHORT).show();
                } else {
                    dbHelper.updateDataProduk(values, id);
                    Toast.makeText(EditActivity.this, "Data berhasil tersimpan", Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
        switch (item.getItemId()){
            case R.id.hapus_produk:
                AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
                builder.setMessage("Hapus produk ini?");
                builder.setCancelable(true);
                builder.setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper.deleteDataProduk(id);
                        Toast.makeText(EditActivity.this, "produk Terhapus", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
        }
        return super.onOptionsItemSelected(item);
    }

        @TargetApi(Build.VERSION_CODES.M)
        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE
                    && resultCode == Activity.RESULT_OK) {
                Uri imageuri = CropImage.getPickImageResultUri(this, data);
                if (CropImage.isReadExternalStoragePermissionsRequired(this, imageuri)) {
                    uri = imageuri;
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}
                            , 0);
                } else {
                    startCrop(imageuri);
                }
            }

            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    imageProduk.setImageURI(result.getUri());
                    uri = result.getUri();
                }
            }
        }
    private void startCrop(Uri imageuri) {
        CropImage.activity(imageuri)
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(this);
        uri = imageuri;
    }
}