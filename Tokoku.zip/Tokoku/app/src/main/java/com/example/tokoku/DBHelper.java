package com.example.tokoku;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final String database_name = "tokoku";
    public static final String table_user = "tabel_user";
    public static final String table_produk = "tabel_produk";

    public static final String row_idUser = "_id";
    public static final String row_username = "username";
    public static final String row_password = "password";

    public static final String row_idProduk = "_id";
    public static final String row_namaProduk = "nama_produk";
    public static final String row_hargaProduk = "harga_produk";
    public static final String row_jenisProduk = "jenis_produk";
    public static final String row_stokProduk = "stok_produk";
    public static final String row_deskProduk = "desk_produk";
    public static final String row_imageProduk = "image_produk";

    private SQLiteDatabase db;

    public DBHelper(Context context) {
        super(context, database_name, null , 3);
        db = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryLogin = "CREATE TABLE " + table_user + "(" + row_idUser + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + row_username + " TEXT, " + row_password + " TEXT)";
        db.execSQL(queryLogin);

        String queryProduk = "CREATE TABLE " + table_produk + "(" + row_idProduk + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + row_namaProduk + " TEXT, " + row_hargaProduk + " TEXT, " + row_jenisProduk + " TEXT, "
                + row_stokProduk + " TEXT, " + row_deskProduk + " TEXT, " + row_imageProduk + " TEXT)";
        db.execSQL(queryProduk);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int x) {
        db.execSQL("DROP TABLE IF EXISTS " + table_user);
        db.execSQL("DROP TABLE IF EXISTS " + table_produk);
    }

    public void insertDataUser(ContentValues values) { db.insert(table_user, null, values); }

    public boolean checkUser(String username, String password) {
        String[] columns = {row_idUser};
        SQLiteDatabase db = getReadableDatabase();
        String selection = row_username + "=?" + " and " + row_password + "=?";
        String[] selectionArgs = {username,password};
        Cursor cursor = db.query(table_user, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if (count > 0)
            return true;
        else
            return false;
    }

    public Cursor getDataProduk(){
        Cursor cursor = db.rawQuery("SELECT * FROM " + table_produk, null);
        return cursor;
    }

    public Cursor getDataProdukById(Long id){
        Cursor cursor = db.rawQuery("SELECT * FROM " + table_produk + " WHERE " + row_idProduk + "=" + id, null);
        return cursor;
    }

    public void insertDataProduk(ContentValues values) { db.insert(table_produk, null, values); }

    public void updateDataProduk( ContentValues values, long id ) {
        db.update(table_produk, values, row_idProduk + "=" + id, null);
    }

    public void deleteDataProduk( long id ) { db.delete(table_produk, row_idProduk + "=" + id, null); }

    public Cursor searchDataProduk(String keyword){
        Cursor cursor = db.rawQuery("SELECT * FROM " + table_produk + " WHERE " + row_namaProduk + " like ?" + " ORDER BY " +
                row_idProduk + " DESC ", new String[] { "%" + keyword + "%" }, null);
        return cursor;
    }
}
